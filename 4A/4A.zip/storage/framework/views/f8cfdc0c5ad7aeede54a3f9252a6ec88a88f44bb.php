<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="container mb-4">
    <div class="products">
        <h1><?php echo e($category->name); ?></h1>
        <div class="row list-product">
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($book->category_id == $category->id): ?>
                <div class="card" style="width: 15rem; margin-right:50px;">
                    <img src="<?php echo e($book->image); ?>" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Nama buku: <?php echo e($book->name); ?></h5>
                        <strong class="mb-0">Stok: <?php echo e($book->stok); ?></strong>
                        <p class="card-text">Deskripsi: <?php echo e($book->deskripsi); ?></p>
                        <a href="" class="btn btn-primary">Simpan</a>
                        <a href="#" class="btn btn-warning">Kembalikan</a>
                    </div>
                </div>         
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.container', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\4A\resources\views/welcome.blade.php ENDPATH**/ ?>