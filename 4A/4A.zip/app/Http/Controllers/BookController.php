<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Book;
use App\Category;

class BookController extends Controller
{
    public function home()
    {
        $categories = Category::all();
        $books = Book::all();
        return view('welcome', compact('books', 'categories'));
    }

    public function create()
    {
        $categories = Category::all();
        return view('create', compact('categories'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'stok' => 'required',
            'deskripsi' => 'required'
        ]);
        Book::create($request->all());
        return redirect('/books');
    }

    public function viewProduct()
    {
        $books = Book::all();
        return view('books', compact('books'));
    }

    public function edit($id)
    {
        $categories = Category::all();
        $books = Book::findOrFail($id);
        return view('edit', compact('books', 'categories'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|min:3|max:20',
            'stok' => 'required',
            'deskripsi' => 'required'
        ]);
        Book::findOrFail($id)->update($request->all());
        return redirect('/books');
    }

    public function delete($id)
    {
        Book::destroy($id);
        return back();
    }
}
