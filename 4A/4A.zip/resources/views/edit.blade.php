@extends('template.container')

@section('style')
    <link rel="stylesheet" href="{{asset('style/style.css')}}">
@endsection

@section('content')
<div class="container mt-5" style="width: 33%;">
  <form class="mb-4" action="/update/{{$books->id}}" method="POST">
      @csrf
      @method('PATCH')
      <h1 class="text-center mb-4">Edit Book</h1>
      <div class="form-group">
          <label for="">Nama Buku</label>
      <input value="{{$books->name}}" type="text" class="form-control @error('name') is-invalid @enderror" name="name">
      @error('name') <span class="text-danger">{{$message}}</span> @enderror
      </div>
      <div class="form-group">
        <label for="">Kategori Buku</label>
        <select name="category_id" class="form-control" value="">
          @foreach ($categories as $category)
              <option value="{{$category->id}}">{{$category->name}}</option>
          @endforeach
        </select>
      </div>
      <div class="form-group">
        <label for="">Deskripsi</label>
    <input value="{{$books->deskripsi}}" type="text" class="form-control @error('deskripsi') is-invalid @enderror" name="deskripsi">
    @error('deskripsi') <span class="text-danger">{{$message}}</span> @enderror
    </div>
      <div class="form-group">
          <label for="">Stok</label>
      <input value="{{$books->stok}}" type="number" class="form-control @error('stok') is-invalid @enderror" name="stok">
      @error('stok') <span class="text-danger">{{$message}}</span> @enderror
      </div>
      <button type="submit" id="btn-submit" class="btn btn-primary mt-3">Submit</button>
  </form>
</div>
@endsection