@extends('template.container')

@section('style')
  <link rel="stylesheet" href="{{asset('style/style.css')}}">
@endsection

@section('content')
<div class="container mt-5" style="width: 33%;">
  <form class="mb-4" action="/store" method="POST">
      @csrf
      <h1 class="text-center mb-4">Create Books</h1>
      <div class="form-group">
        <label for="">Name</label>
        <input type="text" class="form-control @error('name') is-invalid @enderror" name="name">
        @error('name') <span class="text-danger">{{$message}}</span> @enderror
      </div>
      <div class="form-group">
        <label for="">Category</label>
        <select name="category_id" class="form-control">
          @foreach($categories as $category)
            <option value="{{$category->id}}">{{$category->name}}</option>
          @endforeach
        </select>
      </div>
      <div class="form-group">
        <label for="">Description</label>
        <input type="text" class="form-control @error('deskripsi') is-invalid @enderror" name="deskripsi">
        @error('deskripsi') <span class="text-danger">{{$message}}</span> @enderror
      </div>
      <div class="form-group">
          <label for="">Stock</label>
          <input type="number" class="form-control @error('stok') is-invalid @enderror" name="stok">
          @error('stok') <span class="text-danger">{{$message}}</span> @enderror
      </div>
      <input type="hidden" class="form-control" name="image" value="/images/book.png">
      <button id="btn-submit" class="btn btn-primary mt-3">Submit</button>
  </form>
</div>
@endsection