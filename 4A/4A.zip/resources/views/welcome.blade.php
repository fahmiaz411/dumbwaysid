@extends('template.container')
@section('content')
@foreach ($categories as $category)
<div class="container mb-4">
    <div class="products">
        <h1>{{$category->name}}</h1>
        <div class="row list-product">
            @foreach ($books as $book)
            @if($book->category_id == $category->id)
                <div class="card" style="width: 15rem; margin-right:50px;">
                    <img src="{{$book->image}}" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Nama buku: {{$book->name}}</h5>
                        <strong class="mb-0">Stok: {{$book->stok}}</strong>
                        <p class="card-text">Deskripsi: {{$book->deskripsi}}</p>
                        <a href="" class="btn btn-primary">Simpan</a>
                        <a href="#" class="btn btn-warning">Kembalikan</a>
                    </div>
                </div>         
            @endif
            @endforeach
        </div>
    </div>
</div>
@endforeach

@endsection