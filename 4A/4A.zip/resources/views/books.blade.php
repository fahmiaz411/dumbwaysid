@extends('template.container')

@section('content')
<div class="container mt-5">
  <h1>Book List</h1>
  <table class="table">
      <thead>
          <tr>
              <th>#</th>
              <th>Name</th>
              <th>Stock</th>
              <th>Description</th>
              <th>Category</th>
              <th>Action</th>
          </tr>
      </thead>
      <tbody>
          @foreach($books as $book)
            <tr>
              <td>{{$loop->iteration}}</td>
            <td>{{$book->name}}</td>
            <td>{{$book->stok}}</td>
            <td>{{$book->deskripsi}}</td>
            <td>{{$book->category->name}}</td>
            <td>
              <a href="/edit/{{$book->id}}" class="btn btn-success">Edit</a>
                <form action="/delete/{{$book->id}}" method="POST">
                    @csrf
                    @method('DELETE')
                   <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </td>
            </tr>
          @endforeach
      </tbody>
  </table>
</div>    
@endsection